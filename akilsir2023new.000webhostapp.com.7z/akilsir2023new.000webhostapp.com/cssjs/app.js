// scroll nav bg change
$(function() {
  var bodyRef = $("body");
    $(window).scroll(function() {    
      var scroll = $(window).scrollTop();
      if (scroll >= 100) {
        bodyRef.addClass("scrolled");
      } else {
        bodyRef.removeClass("scrolled");
      }
    });

  

});

// increment and decreament

$(document).ready(function() {

  const minus = $('.quantminus');

  const plus = $('.quantplus');

  const input = $('.quantinput');

  minus.click(function(e) {

    e.preventDefault();

    var value = input.val();

    if (value > 1) {

      value--;

    }

    input.val(value);

  });

  

  plus.click(function(e) {

    e.preventDefault();

    var value = input.val();

    value++;

    input.val(value);

  })

});

// counter 

        // $('.count').counterUp({

        //   delay: 10,

        //   time: 2000

        // });



// tooltip

try {
$(function () {

  $('[data-toggle="tooltip"]').tooltip()

})
}
catch(err) {
  console.log(err.message);
}








// add class to body
let fileName = window.location.href;
let dClass = '';
if ( fileName.includes('howtoplay') ) {
  dClass = 'howtoplay-11';
} else if ( fileName.includes('star-line') ) {
  dClass = 'star-line-11';
} else if ( fileName.includes('star-line') ) {
  dClass = 'star-line-11';
}
$("body").addClass(dClass);